# reverse
a = list(input().split())
print(*a[::-1])