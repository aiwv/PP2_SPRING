# колво совпадающих
print(len(set(input().split()) & set(input().split())))