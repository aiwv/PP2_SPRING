a = input().split()
for i in range(0, len(a), 2):
    print(a[i], end= " ")